import styled from "styled-components"

export default styled.div`
  h2 {
    font-size: 1.5rem;
    font-weight: bold;
  }
`