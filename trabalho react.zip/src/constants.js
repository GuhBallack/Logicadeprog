export const ALUNOS = [
  {
    matricula: 123456789,
    nome: "João",
    email: "joao@email.com",
  },
  {
    matricula: 987654321,
    nome: "Maria",
    email: "maria@email.com",
  },
  {
    matricula: 312454232,
    nome: "Mateus",
    email: "mateus@email.com",
  },
  {
    matricula: 123456789,
    nome: "Vagner",
    email: "vagner@email.com",
  },
  {
    matricula: 987654321,
    nome: "Laura",
    email: "laura@email.com",
  },
  {
    matricula: 312454232,
    nome: "Lucas",
    email: "lucas@email.com",
  },
]

export const PROFESSORES = [
  {
    matricula: 123456789,
    nome: "Felipe",
    email: "XXXXXXXXXXXXXX",
  },
  {
    matricula: 987654321,
    nome: "Maria",
    email: "XXXXXXXXXXXXXXX",
  },
  {
    matricula: 312454232,
    nome: "Lucas",
    email: "XXXXXXXXXXXXXXXX",
  },
  {
    matricula: 312454232,
    nome: "Fernanda",
    email: "XXXXXXXXXXXXXXXX",
  },

]


export const MONITORES = [
  {
    matricula: 123456789,
    nome: "Jorge",
    email: "XXXXXXXXXXXXXX",
  },
  {
    matricula: 987654321,
    nome: "Tarcio",
    email: "XXXXXXXXXXXXXXX",
  },
]